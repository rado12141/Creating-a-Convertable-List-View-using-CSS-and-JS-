/** Selecting all convertable list elements */
const convertableListEls = document.querySelectorAll('.convertable-list')
/** Selecting the active list view option/button */
const convertableListOptEls = document.querySelectorAll('.view-option>a')

/** Initialize to change view */
const InitConvertView = () => {
    var current_view = document.querySelector('.view-option>a.active').dataset.view || document.querySelectorAll('.view-option>a')[0].dataset.view || 'list'
    convertableListEls.forEach(el => {
        el.dataset.view = current_view
    })
}
convertableListOptEls.forEach(anchor => {
    /** Tigger change view on option/button click */
    anchor.addEventListener('click', function(){
        convertableListOptEls.forEach(ancEl =>{
            if(!!ancEl.classList.contains('active'))
                ancEl.classList.remove('active');
        })
        anchor.classList.add('active');
        InitConvertView()
    })
})

/**
 * On Page Load
 */
var active_view = document.querySelector('.view-option>a.active') || document.querySelectorAll('.view-option>a')[0] || null 
var current_view = active_view.dataset.view || 'list'
if(document.querySelector('.view-option>a.active') === undefined || document.querySelector('.view-option>a.active') === null){
    if(document.querySelectorAll('.view-option>a')[0] !== undefined && document.querySelectorAll('.view-option>a')[0] !== null)
        document.querySelectorAll('.view-option>a')[0].classList.add('active')
}



